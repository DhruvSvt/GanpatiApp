 <footer class="footer-area">
        <div class="footer-widgets">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 d-flex">
                        <div class="fl-widgets my-auto">
                            <img src="assets/images/20240302_182901.png" style="height:70px" alt="" class="footer-logo"> 
                            <!--<div class="fl-single-w">-->
                            <!--    <p>Call Us</p>-->
                            <!--    <h4><a href="tel:9193677889" style=" font-size: inherit;    color: #c5c7ce;">+91 9367 7889</a></h4>-->
                            <!--</div>-->
                            <!--<div class="fl-single-w">-->
                            <!--    <p>Email Us</p>-->
                            <!--    <h4><a href="mailto:info@dhanraajnareshfinance.com" style=" color: #c5c7ce;   font-size: inherit;">info@dhanraajnareshfinance.com</a></h4>-->
                            <!--</div>-->
                        <!--    <div class="f-social">-->
                             
                        <!--    <ul>-->
                                
                        <!--        <li><a href="https://www.facebook.com/profile.php?id=61556912123035&mibextid=ZbWKwL" target="_blank"><i class="fa-brands fa-facebook-f"></i></a></li>-->
                               
                        <!--        <li><a href="https://www.instagram.com/dhanraajnareshfinance/" target="_blank"><i class="fa-brands fa-instagram"></i></a></li>-->
                        <!--    </ul>-->
                        <!--</div>-->
                        </div>
                    </div>
                     <div class="col-md-2 col-6">
                        <div class="f-widgets">
                            <h4>Loans</h4> 
                            <div class="fw-links">
                                <ul>
                                    <li><a href="#">Home Loan</a></li>
                                    <li><a href="#">Personal loan</a></li>
                                    <li><a href="#">Loan against property Loan</a></li>
                                    <li><a href="#">Business loan</a></li>
                                    <li><a href="#">Vehicle loan</a></li>
                                    <li><a href="#">Gold loan</a></li>
                                </ul> 
                            </div>
                        </div>
                    </div>
                     <div class="col-md-2 col-6">
                        <div class="f-widgets">
                            <h4>Credit Card</h4> 
                            <div class="fw-links">
                                <ul>
                                    <li><a href="#">Apply Now</a></li>
                                    <li><a href="#">Track Application</a></li>
                                    <li><a href="#">View Banks</a></li>
                                </ul> 
                            </div>
                        </div>
                    </div>
                      <div class="col-md-2 col-6">
                        <div class="f-widgets">
                            <h4>Insurance</h4> 
                            <div class="fw-links">
                                <ul>
                                    <li><a href="#">Health insurance</a></li>
                                    <li><a href="#">Motor insurance</a></li>
                                    <li><a href="#">Life insurance</a></li>
                                    <li><a href="#">Child insurance plans</a></li>
                                    <li><a href="#">Travel insurance</a></li>
                                    <li><a href="#">Retirement Plans</a></li> 
                                </ul> 
                            </div>
                        </div>
                    </div>
                    
                     <div class="col-md-2 col-6">
                        <div class="f-widgets">
                            <h4>Company</h4> 
                            <div class="fw-links">
                                <ul>
                                    <li><a href="#">About</a></li>
                                    <li><a href="#">Contact</a></li>
                                    <li><a href="#">Career</a></li>
                                    <li><a href="#">Partners</a></li>
                                    <li><a href="#">Privacy Policy</a></li>
                                </ul> 
                            </div>
                        </div>
                    </div>
                    
                   
                </div>
            </div>
        </div>
        
        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                       
                        <div class="fbottom-copyrights">
                            <p>© 2024 dhanraajnareshfinance.com - All Rights Reserved | Designed & Developed By <a style="color: #c5c7ce;
    font-size: inherit;" href="https://svtindia.in/">SVT INDIA</a></p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="f-social"> <ul>
                                
                                <li><a href="https://www.facebook.com/profile.php?id=61556912123035&mibextid=ZbWKwL" target="_blank"><i class="fa-brands fa-facebook-f"></i></a></li>
                               
                                <li><a href="https://www.instagram.com/dhanraajnareshfinance/" target="_blank"><i class="fa-brands fa-instagram"></i></a></li>
                            </ul> </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
 
 <div class="modal fade" id="exampleModal1" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Enquire Now</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="get-in-touch-content">
                        <div class="section-head">
                            <p>&nbsp;</p>
                            <h3>Request A Call Back!</h3>
                        </div>

                        <div class="gitouch-form">
                            <form action="#" >
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="full_name">Your Full Name *</label>
                                            <input type="text" name="full_name" id="full_name" placeholder="Full Name">
                                        </div>
                                        <div class="form-group">
                                            <label for="phone">Phone Number *</label>
                                            <input type="text" name="phone" id="phone" placeholder="Phone Number">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="email_a">Email Address</label>
                                            <input type="email" name="email_a" id="email_a" placeholder="Your Email">
                                        </div>
                                        <div class="form-group">
                                            <label for="i_type">Service Type **</label>
                                            <select name="i_type" id="i_type">
                                                <option>Home Loan</option><option>Loan against property(LAP)</option><option>Business loan</option><option>Personal loan</option><option>Vehicle loan</option><option>Gold Loan</option><option>Health insurance</option><option>Motor insurance</option><option>Life insurance</option><option>Child insurance plans</option><option>Travel insurance</option><option>Retirement Plans</option>
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-12">
                                        <div class="gitouch-submit">
                                            <input type="submit" class="btn-style-a" value="Get a Call">
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
               
            </div>
        </div>
      </div>
       
    </div>
  </div>
</div>
 
    
     <script src="assets/js/jquery-3.2.0.min.js"></script> 
    <!-- Owl Carousel Plugin -->
   <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.2.1/owl.carousel.min.js"></script>
    <!-- Main Counterup Plugin-->
    <script src="assets/js/jquery.counterup.min.js"></script>  
    <script src="assets/js/jquery.scrollUp.js"></script>
    <script src="assets/js/jquery.mixitup.min.js"></script>
    <script src="assets/js/jquery.waypoints.min.js"></script>
    <script src="assets/js/lightbox.js"></script>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"  ></script>
    <!-- Main Script -->
    <script src="assets/js/theme.js"></script>