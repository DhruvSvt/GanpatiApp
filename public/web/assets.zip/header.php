  <header class="header-section bgadd ">
        <div class="container">
           
                <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
   
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
     <a class="navbar-brand" href="index.php"><img src="assets/images/logo-dhanraj.jpg" alt="logo"></a>
     <a href="#" class="mr-btn mobile-h-sign-in">Join Us</a>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mb-2 mb-lg-0 ms-auto">
        <li class="nav-item">
          <a class="nav-link" href="index.php">Home</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Services
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="#">Loan</a></li>
            <li><a class="dropdown-item" href="#">Credit Card</a></li>
            <li><a class="dropdown-item" href="#">Insurance</a></li>
          </ul>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="about.php">About Us</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="career.php">Career</a>
        </li>
         <li class="nav-item">
          <a class="nav-link" href="contact.php">Contact Us</a>
        </li>
        
      </ul>
      <div class="menu-right-components">
                    <div class="menur-components">
                        <a href="#" class="mr-btn h-sign-in">Join Us</a>
                        <!--<a href="#" class="mr-btn h-sign-up">Sign Up</a>-->
                    </div>
                    <div class="header-bar d-lg-none">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                </div>
    </div>
  </div>
</nav>
                
           
        </div>
    </header>